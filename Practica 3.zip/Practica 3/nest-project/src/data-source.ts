/* eslint-disable prettier/prettier */
import { DataSource, DataSourceOptions } from 'typeorm';
import { config } from 'dotenv';

config(); // Load .env file if you use one for environment variables

// Base options, potentially for runtime
export const dataSourceOptions: DataSourceOptions = {
    type: 'postgres',
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    username: process.env.DB_USERNAME || 'postgres', // Ensure these match your DB credentials
    password: process.env.DB_PASSWORD || 'ITDPromocion', // Ensure these match your DB credentials
    database: process.env.DB_DATABASE || 'my_db', // Ensure this is your database name
    entities: [
        'dist/**/*.entity.js', // For runtime after build
    ],
    migrations: [
        'dist/database/migrations/*.js', // For runtime after build
    ],
    synchronize: false, // Never true in production
    migrationsTableName: 'migrations',
    logging: process.env.NODE_ENV === 'development', // Enable logging in development
};

// CLI-specific options: Use .ts files for generation and direct execution
// The TypeORM CLI, when run with ts-node, needs to find .ts files.
// The first path in `migrations` is used by `migration:generate -n <name>`
// to determine where to create new migration files.
export const cliDataSourceOptions: DataSourceOptions = {
    ...dataSourceOptions, // Inherit base options
    entities: ['src/**/*.entity.ts'], // Point to .ts entity files for CLI
    migrations: ['src/database/migrations/*.ts'], // Point to .ts migration files for CLI
};

// Export the DataSource instance configured for CLI use
const AppDataSource = new DataSource(cliDataSourceOptions);
export default AppDataSource;